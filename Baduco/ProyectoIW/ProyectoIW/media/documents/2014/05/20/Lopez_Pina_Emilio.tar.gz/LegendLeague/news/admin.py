from django.contrib import admin
from news.models import New

admin.site.register(New)
