from django.contrib import admin
from principal.models import Jugador,Equipo,Arbitro,Jornada,Partido,Participa

admin.site.register(Jugador)
admin.site.register(Equipo)
admin.site.register(Arbitro)
admin.site.register(Jornada)
admin.site.register(Partido)
admin.site.register(Participa)
